<?php return array('dependencies' => array('lodash', 'react', 'react-dom'), 'version' => '92cac508fac197dd6ddf');
