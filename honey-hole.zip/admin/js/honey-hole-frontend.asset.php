<?php return array('dependencies' => array('react', 'react-dom', 'wp-element'), 'version' => '7c3287a1a8547318fa25');
