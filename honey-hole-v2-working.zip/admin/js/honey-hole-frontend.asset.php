<?php return array('dependencies' => array('react', 'react-dom', 'wp-element'), 'version' => '3ec47e30628ff5bb52d2');
