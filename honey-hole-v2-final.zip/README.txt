=== Honey Hole ===
Contributors: jackballdev
Donate link: N/A
Tags: comments, spam
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Honey Hole plugin for Outdoor Empire. Built for the purpose of managing and displaying deals on the Honey Hole.

== Installation ==

1. Upload `honey-hole.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.0 =
* MVP up and running.
* WP Admins can add, edit and delete deals.
* Users can see and clickthrough deals on the page
* PHP rendered frontend

= 2.0 =
* Under the Hood
- Migrated from PHP based app to React based app
- Adds WP API endpoints

* New Features
- Sorting on frontend and backend by deal category
- Adds Youtube video on frontend
- Squashed Bugs.
- Improved Backend UI

== Upgrade Notice ==



