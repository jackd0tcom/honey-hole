<?php return array('dependencies' => array('react', 'wp-element'), 'version' => '79e198aefa90edf1bd46');
