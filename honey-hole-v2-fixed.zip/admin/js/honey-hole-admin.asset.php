<?php return array('dependencies' => array('lodash', 'react', 'react-dom'), 'version' => 'cfec8b1a64c191573f73');
